﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;

namespace Archivos
{
    public class Texto:IArchivo<string>
    {
        public bool guardar(string archivo, string datos)
        {
            try
            {
                //con el bloque using, si se produce un error, o si se cumple correctamente lo que esta dentro, luego elimina todas las dependencias, es decir, cierra los
                //archivos abiertos, etc. Evito tener que poner sw.Close();. Con true en el StreamWriter, appendeo.

                using (StreamWriter escribirArchivo = new StreamWriter(archivo,true))
                {
                    escribirArchivo.WriteLine(datos);
                }
                return true;
            }
            catch(Exception e)
            {
                throw new ArchivosException(e); 
            }
        }

        public bool leer(string archivo, out string datos)
        {
            try
            {
                using (StreamReader leerArchivo = new StreamReader(archivo))
                {
                    datos = leerArchivo.ReadToEnd();
                }
                return true;
            }
            catch(Exception e)
            {
                datos = "";
                throw new ArchivosException(e.InnerException);
            }
        }
    }
}
