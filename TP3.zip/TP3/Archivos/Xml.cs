﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T>
    {
        public bool guardar(string archivo, T datos)
        {
            try
            {
                XmlSerializer Xserializar = new XmlSerializer(typeof(T));
                StreamWriter escribirArchivo = new StreamWriter(archivo);
                Xserializar.Serialize(escribirArchivo, datos);
                escribirArchivo.Close();
                return true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e.InnerException);
            }
        }

        public bool leer(string archivo, out T datos)
        {
            try
            {
                XmlSerializer Xserializar = new XmlSerializer(typeof(T));
                StreamReader leerArchivo = new StreamReader(archivo);
                datos = (T)Xserializar.Deserialize(leerArchivo);
                leerArchivo.Close();
                return true;
            }
            catch (Exception e)
            {
                datos = default(T); //El default se utiliza para devolver T en su forma original ya que se produjo un error al deserializar.

                throw new ArchivosException(e);
            }
        }
    }
}
