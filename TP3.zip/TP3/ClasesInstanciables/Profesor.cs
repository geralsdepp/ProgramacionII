﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor:Universitario
    {
        private Queue<Universidad.EClases> _clasesDelDia;
        private static Random _random;

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        private void _randomClases()
        {
            this._clasesDelDia.Enqueue((Universidad.EClases)(Profesor._random.Next(0, 4)));
            this._clasesDelDia.Enqueue((Universidad.EClases)(Profesor._random.Next(0, 4)));
        }

        protected override string MostrarDatos()
        {
            StringBuilder SBuilder = new StringBuilder();

            SBuilder.AppendLine(base.MostrarDatos());
            SBuilder.AppendLine(this.ParticiparEnClase());
            return SBuilder.ToString();
        }

        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }
        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
            bool retorno = false;

            if(i._clasesDelDia.Contains(clase))
            {
                retorno = true;
            }
            return retorno;
        }

        protected override string ParticiparEnClase()
        {
            StringBuilder SBuilder = new StringBuilder();
            SBuilder.AppendLine("CLASES DEL DIA ");
            //el método ElementAtOrDefault es parecido al método ElementAt, con la diferencia de que si le pasamos un índice que no existe en la cola,
            //elige el predeterminado, de esta manera evitamos que el programa pinche por buscar un valor fuera de rango. A diferencia del método Dequeue, el
            //método mencionado, trae un elemento de la cola sin quitarlo de la misma.
            SBuilder.AppendLine(this._clasesDelDia.ElementAtOrDefault(0).ToString());
            SBuilder.AppendLine(this._clasesDelDia.ElementAtOrDefault(1).ToString());
            return SBuilder.ToString();
        }

        public Profesor()
        {
            this._clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
        }

        static Profesor()
        {
            Profesor._random = new Random();
        }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :this()
        {
            base.Apellido = apellido;
            base.Nombre = nombre;
            base.StringToDni = dni;
            base.Nacionalidad = nacionalidad;
            this.legajo = id;
        }

       

        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}   
