﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion, Laboratorio, Legislacion, SPD
        }

        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;
        private string path = "J:\\UTN\\Programación.2017\\C#\\TPS\\TP3\\2017-TP3-Archivos\\Universidad";

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }

        public List<Profesor> Instructores
        {
            get { return this.profesores; }
            set { this.profesores = value; }
        }

        public List<Jornada> Jornadas
        {
            get { return this.jornada; }
            set { this.jornada = value; }
        }

        public Jornada this[int i]
        {
            get
            {
                try
                {
                    return this.jornada[i];
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
            set
            {
                try
                {
                    this.jornada[i] = value;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        public static bool Guardar(Universidad gim)
        {
            Xml<Universidad> xmlguardar = new Xml<Universidad>();
            xmlguardar.guardar(gim.path, gim);
                return true;
           

        }

        public static Universidad Leer()
        {
            Universidad aux = null;

            Xml<Universidad> xmlLeer = new Xml<Universidad>();

            xmlLeer.leer("Universidad", out aux);
            return aux;
        }

        private static string MostrarDatos(Universidad gim)
        {
            StringBuilder SBuilder = new StringBuilder();

            SBuilder.AppendLine("JORNADA:");
            foreach (Jornada item in gim.Jornadas)
            {
                SBuilder.AppendLine(item.ToString());
            }
            return SBuilder.ToString();
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        public static Profesor operator !=(Universidad g, EClases clase)
        {
            Profesor retorno = null;
            if ((g == clase) != null)
                retorno = (g == clase);
            return retorno;
        }

        public static bool operator != (Universidad g, Profesor i)
        {
            return !(g == i);
        }

        public static Universidad operator +(Universidad g, Alumno a)
        {
            if (!(g == a))
            {
                g.Alumnos.Add(a);
            }
            return g;
        }

        public static Universidad operator +(Universidad g, EClases clase)
        {
            Profesor p = new Profesor();
            
            if (p == clase)
            {
                Jornada j = new Jornada(clase, p);
                foreach (Alumno item in j.Alumnos)
                {
                    if (item == clase)
                    {
                        g+=item;
                    }
                }
            }
            return g;
            
        }

        public static Universidad operator + (Universidad g, Profesor i)
        {
            if (!(g == i))
            {
                g.Instructores.Add(i);
            }
            return g;
        }

        public static bool operator ==(Universidad g, Alumno a)
        {
            bool retorno = false;

            if (g.Alumnos.Contains(a))
            {
                retorno = true;
            }
            return retorno;
        }

        // retornará el primer Profesor capaz de dar esa clase.
        //Sino, lanzará la Excepción SinProfesorException.
        public static Profesor operator ==(Universidad g, EClases clase)
        {
            Profesor retorno =null;

            foreach (Jornada item in g.Jornadas)
            {
                if (clase == item.Clase)
                {
                    retorno = item.Instructor;
                }
                else
                    throw new SinProfesorException();

            }
            return retorno;
        
        }

        public static bool operator ==(Universidad g, Profesor i)
        {
            bool retorno = false;

            if (g.Instructores.Contains(i))
            {
                retorno = true;
            }
            return retorno;
        }

        public override string ToString()
        {
            return (string)Universidad.MostrarDatos(this);
        }

        public Universidad()
        {
            this.Alumnos = new List<Alumno>();
            this.Instructores = new List<Profesor>();
            this.Jornadas = new List<Jornada>();
        }
    }
}
