﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> _alumnos;
        private Universidad.EClases _clase;
        private Profesor _instructor;
        string path = "J:\\UTN\\Programación.2017\\C#\\TPS\\TP3\\2017-TP3-Archivos\\Jornada.tct";

        public List<Alumno> Alumnos
        {
            get { return this._alumnos; }
            set { this._alumnos = value; }
        }

        public Universidad.EClases Clase
        {
            get { return this._clase; }
            set { this._clase = value; }
        }

        public Profesor Instructor
        {
            get { return this._instructor; }
            set { this._instructor = value; }
        }

        public static bool Guardar(Jornada jornada)
        {
            Texto txt = new Texto();
            txt.guardar("Jornada.txt", jornada.ToString());
                return true;
            
        }

        private Jornada()
        {
            this._alumnos = new List<Alumno>();
        }

        public Jornada(Universidad.EClases clase, Profesor instructor)
            :this()
        {
            this.Clase = clase;
            this.Instructor = instructor;
        }

        public static string Leer()
        {
            string aux;
            Texto txt = new Texto();
            txt.leer("Jornada.txt", out aux);
            return aux;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static bool operator ==(Jornada j, Alumno a)
        {
            bool retorno = false;
            if (j._alumnos.Contains(a))
            {
                retorno = true;
            }
            return retorno;
        }

        public static Jornada operator +(Jornada j, Alumno a)
        {
            if (j != a)
            {
                j.Alumnos.Add(a);
            }
            return j;
        }

        public override string ToString()
        {
            StringBuilder SBuilder = new StringBuilder();

            SBuilder.AppendLine("Clase: {0}" + this.Clase);
            SBuilder.AppendLine("Profesor: {0}" + this.Instructor);

            foreach (Alumno a in this.Alumnos)
            {
                SBuilder.AppendLine("Alumno: {0}" + a.ToString());
            }

            return SBuilder.ToString();
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
