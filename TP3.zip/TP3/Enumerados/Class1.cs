﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumerados
{
    public enum EEstadoCuenta
    {
        AlDia, Deudor, Becado
    }

    public enum EClases
    {
        Programacion, Laboratorio, Legislacion, SPD
    }

    public enum ENacionalidad
    {
        Argentino, Extranjero
    }
}
